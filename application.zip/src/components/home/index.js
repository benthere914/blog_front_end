import './index.css'

const Home = () => {
    return (
        <>
            <p>at the home page</p>
        </>
    )
}

export default Home
